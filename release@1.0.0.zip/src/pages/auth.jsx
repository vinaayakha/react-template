

export default function AuthComponent() {
    return (
        <>
        Auth Page
        </>
    )
}